import cv2
import os
import numpy as np
import streamlit as st

def preprocess_image(image):
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Appliquer un flou gaussien et un seuillage adaptatif
    blurred_image = cv2.GaussianBlur(gray_image, (5, 5), 0)
    _, binary_image = cv2.threshold(blurred_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # Fermeture morphologique
    kernel = np.ones((5, 5), np.uint8)
    closed_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
    
    return closed_image

def extract_hu_moments(image):
    contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    largest_contour = max(contours, key=cv2.contourArea)
    
    # Calculer les moments de Hu
    moments = cv2.moments(largest_contour)
    hu_moments = cv2.HuMoments(moments).flatten()
        
    # Convertir en type de données CV_32F
    hu_moments_normalized = hu_moments.astype(np.float32)
    
    return hu_moments_normalized


def calculate_and_normalize_histogram(image, color_space=cv2.COLOR_BGR2Lab):
    # Convertir l'image dans l'espace colorimétrique spécifié
    converted_image = cv2.cvtColor(image, color_space)
    
    # Calcule l'histogramme et le normalise
    hist = cv2.calcHist([converted_image], [0, 1, 2], None, [256, 256, 256], [0, 256, 0, 256, 0, 256])
    norm_hist = hist.flatten() / np.sum(hist)
    
    return norm_hist


def compare_images(img1, img2, hist1,hu_moments1):
    
    hist2 = calculate_and_normalize_histogram(img2, color_space=cv2.COLOR_BGR2Lab)

    # Utiliser la corrélation au lieu de la norme Euclidienne
    color_similarity = cv2.compareHist(np.array([hist1]), np.array([hist2]), cv2.HISTCMP_INTERSECT)

    preprocessed_img2 = preprocess_image(img2)
    hu_moments2 = extract_hu_moments(preprocessed_img2)
    hu_moments2 = hu_moments2.astype(np.float32)
    
    # Utiliser l'intersection au lieu de la norme Euclidienne
    shape_similarity = cv2.compareHist(np.array([hu_moments1]), np.array([hu_moments2]), cv2.HISTCMP_INTERSECT)
    
    rate = 0.7
    res = rate * color_similarity + (1-rate)*shape_similarity
    return res

# Fonction pour afficher plusieurs images dans des colonnes
def display_images_in_columns(images, column_number):
    columns = st.columns(column_number)
    
    for i, image_path in enumerate(images, 1):
        col = columns[i % column_number]
        with col:
            st.image(image_path[0], use_column_width=True, caption=os.path.basename(image_path[0]))
            st.write("")  # Ajouter un espace entre les images


def main():
    image_directory = './bondataset/'
    image_database = [os.path.join(image_directory, file) for file in os.listdir(image_directory) if file.lower().endswith(('.png', '.jpg', '.jpeg'))]

    st.title("Image Similarity Search")
    
    uploaded_file = st.file_uploader("Choisir une image:", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        with open("uploads/uploaded_image.jpg", "wb") as f:
            f.write(uploaded_file.read())

        st.image("uploads/uploaded_image.jpg", caption="Uploaded Image", use_column_width=True)

        image1_path = "uploads/uploaded_image.jpg"
        img1 = cv2.imread(image1_path)
        preprocessed_img1 = preprocess_image(img1)
        hu_moments1 = extract_hu_moments(preprocessed_img1)
        hu_moments1 = hu_moments1.astype(np.float32)
        hist1 = calculate_and_normalize_histogram(img1, color_space=cv2.COLOR_BGR2Lab)
        img1_similarity = []

        for image2_path in image_database:
            img2 = cv2.imread(image2_path)
            similarity = compare_images(img1, img2, hist1, hu_moments1)
            #print(similarity)
            if similarity != np.nan and similarity>0.5:
                img1_similarity.append((image2_path, similarity))

        sorted_similarity = sorted(img1_similarity, key=lambda x: x[1], reverse=True)

        st.header("Images Similaires basées sur la Forme (Moments de Hu) avec Corrélation :")

        display_images_in_columns(sorted_similarity[:5],3)

if __name__ == "__main__":
    main()
